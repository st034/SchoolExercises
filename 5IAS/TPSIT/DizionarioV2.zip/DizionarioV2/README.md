# How to compile and execute this exercise

## Compile

* Open __powershell__ or __cmd__ or __git bash__;

* __cd__ to the repository of this exercise;

* Run these commands to compile:

    * `javac -cp ./lib/json-simple-1.1.jar Server.java`
    * `javac -cp ./lib/json-simple-1.1.jar Client.java`

## Execute

Open 2 shell, from the first shell execute this command:

* `java -cp ./lib/json-simple-1.1.jar Server`

From the second shell execute this:

* `java -cp ./lib/json-simple-1.1.jar Client`

Have fun!